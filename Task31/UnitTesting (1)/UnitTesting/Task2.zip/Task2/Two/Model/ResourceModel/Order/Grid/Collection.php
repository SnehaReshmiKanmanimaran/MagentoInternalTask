<?php
namespace Tychons\Two\Model\ResourceModel\Order\Grid;

use Magento\Sales\Model\ResourceModel\Order\Grid\Collection as OriginalCollection;

/**
 *
 * This Model file is used to left join
 *
 */
class Collection extends OriginalCollection
{
    /**
     * This method is used to left join the table
     *
     * @return void
     */
    protected function _renderFiltersBefore()
    {
        $this->getSelect()->joinLeft(
            ['sales_order' => $this->getTable('sales_order')],
            'main_table.entity_id = sales_order.entity_id',
            ['order_random' => 'sales_order.order_random']
        );

        parent::_renderFiltersBefore();
    }
}
