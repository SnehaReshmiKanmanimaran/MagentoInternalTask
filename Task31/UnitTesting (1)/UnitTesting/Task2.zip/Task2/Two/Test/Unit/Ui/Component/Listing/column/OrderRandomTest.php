<?php
namespace Tychons\Two\Test\Unit\Ui\Component\Listing\Column;

use PHPUnit\Framework\TestCase;
use Tychons\Two\Ui\Component\Listing\Column\OrderRandom;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Sales\Model\OrderRepository;
use Magento\Sales\Model\Order;

class OrderRandomTest extends TestCase
{
    /**
     * @var OrderRandom
     */
    private $orderRandom;

    /**
     * @var ContextInterface|\PHPUnit\Framework\MockObject\MockObject
     */
    private $contextMock;

    /**
     * @var UiComponentFactory|\PHPUnit\Framework\MockObject\MockObject
     */
    private $uiComponentFactoryMock;

    /**
     * @var OrderRepository|\PHPUnit\Framework\MockObject\MockObject
     */
    private $orderRepositoryMock;

    protected function setUp(): void
    {
        $this->contextMock = $this->createMock(ContextInterface::class);
        $this->uiComponentFactoryMock = $this->createMock(UiComponentFactory::class);
        $this->orderRepositoryMock = $this->createMock(OrderRepository::class);

        $this->orderRandom = new OrderRandom(
            $this->contextMock,
            $this->uiComponentFactoryMock,
            $this->orderRepositoryMock,
            [],
            []
        );
    }

    public function testPrepareDataSource()
    {
        $orderId = 1;
        $randomValue = 123456;

        $orderMock = $this->createMock(Order::class);
        $orderMock->method('getData')->with('order_random')->willReturn($randomValue);
        $this->orderRepositoryMock->method('get')->with($orderId)->willReturn($orderMock);

        $dataSource = [
            'data' => [
                'items' => [
                    ['entity_id' => $orderId, 'order_random' => $randomValue]
                ]
            ]
        ];

        $result = $this->orderRandom->prepareDataSource($dataSource);
        
        $this->assertEquals($randomValue, $result['data']['items'][0]['order_random']);
    }
}
