<?php

namespace Tychons\Two\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory as OrderCollectionFactory;
use Psr\Log\LoggerInterface;

/**
 * Observer for handling actions after an order is placed.
 */
class OrderPlaceAfter implements ObserverInterface
{
    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var OrderCollectionFactory
     */
    private $orderCollectionFactory;

    /**
     * @param LoggerInterface $logger
     * @param OrderCollectionFactory $orderCollectionFactory
     */
    public function __construct(LoggerInterface $logger, OrderCollectionFactory $orderCollectionFactory)
    {
        $this->logger = $logger;
        $this->orderCollectionFactory = $orderCollectionFactory;
    }

    /**
     * Execute method after order placement.
     *
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer)
    {
        $order = $observer->getEvent()->getOrder();

        $randomKey = $this->generateUniqueRandomKey();

        $order->setOrderRandom($randomKey);
        $order->save();
    }

    /**
     * Generate a unique random key.
     *
     * @return int
     */
    protected function generateUniqueRandomKey()
    {
        $keyLength = 6;
        $randomKey = '';
        do {
            $randomKey = random_int(pow(10, $keyLength - 1), pow(10, $keyLength) - 1);
            $isUnique = $this->isRandomKeyExists($randomKey);
        } while ($isUnique);
        return $randomKey;
    }

    /**
     * Check if random key already exists.
     *
     * @param int $randomKey
     * @return mixed
     */
    protected function isRandomKeyExists($randomKey)
    {
        // Check if orderCollectionFactory is null
        if ($this->orderCollectionFactory === null) {
            $this->logger->error('OrderCollectionFactory is null');
            return false;
        }

        $existingOrder = $this->orderCollectionFactory->create()
            ->addFieldToFilter('order_random', $randomKey)
            ->getFirstItem();

        return $existingOrder->getId();
    }
}
