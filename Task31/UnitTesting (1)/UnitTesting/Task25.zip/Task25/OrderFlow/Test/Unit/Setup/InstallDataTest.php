<?php

namespace Tychons\OrderFlow\Test\Unit\Setup;

use PHPUnit\Framework\TestCase;
use Tychons\OrderFlow\Setup\InstallData;
use Magento\Sales\Model\Order\StatusFactory;
use Magento\Sales\Model\ResourceModel\Order\StatusFactory as StatusResourceFactory;
use Magento\Sales\Model\ResourceModel\Order\Status as StatusResource;
use Magento\Sales\Model\Order\Status;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;

class InstallDataTest extends TestCase
{
    private $statusFactoryMock;
    private $statusResourceFactoryMock;
    private $installData;

    protected function setUp(): void
    {
        $this->statusFactoryMock = $this->createMock(StatusFactory::class);
        $this->statusResourceFactoryMock = $this->createMock(StatusResourceFactory::class);
        $this->installData = new InstallData(
            $this->statusFactoryMock,
            $this->statusResourceFactoryMock
        );
    }

    public function testInstall()
    {
        $setupMock = $this->createMock(ModuleDataSetupInterface::class);
        $contextMock = $this->createMock(ModuleContextInterface::class);

        $statusMock = $this->createMock(Status::class);
        $statusResourceMock = $this->createMock(StatusResource::class);

        $this->statusFactoryMock->method('create')->willReturn($statusMock);
        $this->statusResourceFactoryMock->method('create')->willReturn($statusResourceMock);

        $statusMock->expects($this->exactly(2))->method('setData');
        $statusResourceMock->expects($this->exactly(2))->method('save')->with($statusMock);

        $this->installData->install($setupMock, $contextMock);
    }
}
