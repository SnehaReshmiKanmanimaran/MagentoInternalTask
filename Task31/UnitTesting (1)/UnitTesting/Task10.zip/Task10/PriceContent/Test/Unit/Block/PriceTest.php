<?php

namespace Tychons\PriceContent\Test\Unit\Block;

use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;
use Tychons\PriceContent\Block\Price;
use Magento\Framework\Registry;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Catalog\Model\Product;
use Magento\Quote\Model\Quote;

class PriceTest extends TestCase
{
    /**
     * @var Price
     */
    protected $block;

    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    protected $registryMock;

    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    protected $checkoutSessionMock;

    protected function setUp(): void
    {
        $objectManager = new ObjectManager($this);

        $this->registryMock = $this->createMock(Registry::class);
        $this->checkoutSessionMock = $this->createMock(CheckoutSession::class);

        $this->block = $objectManager->getObject(
            Price::class,
            [
                'registry' => $this->registryMock,
                'checkoutSession' => $this->checkoutSessionMock,
            ]
        );
    }

    public function testGetCurrentProduct()
    {
        $productMock = $this->createMock(Product::class);
        $this->registryMock->expects($this->once())
            ->method('registry')
            ->with('current_product')
            ->willReturn($productMock);

        $this->assertSame($productMock, $this->block->getCurrentProduct());
    }

    public function testGetCurrentProductPrice()
    {
        $productPrice = 2400.00;
        $productMock = $this->createMock(Product::class);
        $productMock->method('getPrice')->willReturn($productPrice);

        $this->registryMock->method('registry')->with('current_product')->willReturn($productMock);

        $expectedPrice = $productPrice / Price::DIVIDE_VALUE;
        $this->assertEquals($expectedPrice, $this->block->getCurrentProductPrice());
    }

    public function testGetCurrentQuotePrice()
    {
        $quotePrice = 4800.00;
        $quoteMock = $this->createMock(Quote::class);
        $quoteMock->method('getBaseGrandTotal')->willReturn($quotePrice);

        $this->checkoutSessionMock->method('getQuote')->willReturn($quoteMock);

        $expectedPrice = $quotePrice / Price::DIVIDE_VALUE;
        $this->assertEquals($expectedPrice, $this->block->getCurrentQuotePrice());
    }

    public function testDivideValue()
    {
        $this->assertEquals(Price::DIVIDE_VALUE, $this->block->divideValue());
    }
}
