<?php

namespace Tychons\PriceContent\Test\Unit\Helper;

use PHPUnit\Framework\TestCase;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Store\Model\Store;
use Tychons\PriceContent\Helper\Data;

class DataTest extends TestCase
{
    /**
     * @var Data
     */
    protected $helper;

    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    protected $storeManagerMock;

    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    protected $storeMock;

    protected function setUp(): void
    {
        $this->storeManagerMock = $this->createMock(StoreManagerInterface::class);
        $this->storeMock = $this->createMock(Store::class);

        $this->storeManagerMock->method('getStore')->willReturn($this->storeMock);

        $this->helper = new Data($this->storeManagerMock);
    }

    public function testGetCurrencySymbolForStoreId2()
    {
        $this->storeMock->method('getId')->willReturn(2);

        $this->assertEquals('$US', $this->helper->getCurrencySymbol());
    }

    public function testGetCurrencySymbolForOtherStore()
    {
        $currencySymbol = '£';
        $this->storeMock->method('getId')->willReturn(1);
        $this->storeMock->method('getCurrentCurrency')->willReturn(
            $this->createConfiguredMock(\Magento\Directory\Model\Currency::class, ['getCurrencySymbol' => $currencySymbol])
        );

        $this->assertEquals($currencySymbol, $this->helper->getCurrencySymbol());
    }
}
