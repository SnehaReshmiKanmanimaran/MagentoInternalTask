<?php 
namespace Tychons\PriceContent\Block;
 
class Price extends \Magento\Framework\View\Element\Template
{
    const DIVIDE_VALUE = 48;

    protected $registry;
    protected $checkoutSession;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Checkout\Model\Session $checkoutSession,
        array $data = []
    )
    {
        $this->registry = $registry;
        $this->checkoutSession = $checkoutSession;
        parent::__construct($context, $data);
    }

    public function getCurrentProduct()
    {
        return $this->registry->registry('current_product');
    }

    public function getCurrentProductPrice()
    {
        $currentProduct = $this->getCurrentProduct();
        return $currentProduct->getPrice() / self::DIVIDE_VALUE;
    }

    public function getCurrentQuotePrice()
    {
        $quote = $this->checkoutSession->getQuote();
        return $quote->getBaseGrandTotal() / self::DIVIDE_VALUE;
    }

    public function divideValue()
    {
        return self::DIVIDE_VALUE;
    }

}

 
