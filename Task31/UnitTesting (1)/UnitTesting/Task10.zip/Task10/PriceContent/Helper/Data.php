<?php
namespace Tychons\PriceContent\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\StoreManagerInterface;

class Data extends AbstractHelper
{
    protected $storeManager;

    public function __construct(
        StoreManagerInterface $storeManager
    ) {
        $this->storeManager = $storeManager;
    }

    public function getCurrencySymbol()
    {
        $storeId = $this->storeManager->getStore()->getId();
        
       if ($storeId =='2') {
            return '$US';  
        } else {
            $currencySymbol = $this->storeManager->getStore($storeId)->getCurrentCurrency()->getCurrencySymbol();
            return $currencySymbol;
        }
    }
}


 
 

