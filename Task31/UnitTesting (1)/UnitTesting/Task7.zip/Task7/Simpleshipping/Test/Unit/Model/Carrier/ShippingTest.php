<?php
 
 namespace Tychons\Simpleshipping\Test\Unit\Model\Carrier;

 use Magento\Framework\App\Config\ScopeConfigInterface;
 use Magento\Quote\Model\Quote\Address\RateRequest;
 use Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory;
 use Magento\Quote\Model\Quote\Address\RateResult\Method;
 use Magento\Quote\Model\Quote\Address\RateResult\MethodFactory;
 use Magento\Shipping\Model\Rate\ResultFactory;
 use Psr\Log\LoggerInterface;
 use Tychons\Simpleshipping\Model\Carrier\Shipping;
 use PHPUnit\Framework\TestCase;
 
 class ShippingTest extends TestCase
 {
     /**
      * @var Shipping
      */
     private $shipping;
 
     /**
      * @var \PHPUnit\Framework\MockObject\MockObject
      */
     private $scopeConfigMock;
 
     /**
      * @var \PHPUnit\Framework\MockObject\MockObject
      */
     private $rateErrorFactoryMock;
 
     /**
      * @var \PHPUnit\Framework\MockObject\MockObject
      */
     private $loggerMock;
 
     /**
      * @var \PHPUnit\Framework\MockObject\MockObject
      */
     private $rateResultFactoryMock;
 
     /**
      * @var \PHPUnit\Framework\MockObject\MockObject
      */
     private $rateMethodFactoryMock;
 
     /**
      * @var \PHPUnit\Framework\MockObject\MockObject
      */
     private $rateRequestMock;
 
     protected function setUp(): void
     {
         $this->scopeConfigMock = $this->createMock(ScopeConfigInterface::class);
         
         // Commented out ErrorFactory since it might not be necessary for your test
         // $this->rateErrorFactoryMock = $this->createMock(ErrorFactory::class);
 
         $this->loggerMock = $this->createMock(LoggerInterface::class);
        // $this->rateResultFactoryMock = $this->createMock(ResultFactory::class);
        // $this->rateMethodFactoryMock = $this->createMock(MethodFactory::class);
         $this->rateRequestMock = $this->createMock(RateRequest::class);
 
         $this->shipping = new Shipping(
             $this->scopeConfigMock,
             $this->loggerMock,
             $this->rateResultFactoryMock,
             $this->rateMethodFactoryMock
         );
     }
 
     public function testCollectRatesReturnsFalseIfNotActive()
     {
         $this->scopeConfigMock->method('getValue')
             ->with('carriers/simpleshipping/active')
             ->willReturn(false);
 
         $this->assertFalse($this->shipping->collectRates($this->rateRequestMock));
     }
 
     public function testCollectRatesReturnsFalseIfDestinationIsNotCA()
     {
         $this->scopeConfigMock->method('getValue')
             ->with('carriers/simpleshipping/active')
             ->willReturn(true);
 
         $this->rateRequestMock->method('getDestCountryId')
             ->willReturn('US');
 
         $this->assertFalse($this->shipping->collectRates($this->rateRequestMock));
     }
 }
 