<?php

namespace Tychons\AdminCustomerTab\Test\Unit\Block\Adminhtml\CustomerEdit\Tab;

use PHPUnit\Framework\TestCase;
use Tychons\AdminCustomerTab\Block\Adminhtml\CustomerEdit\Tab\View;
use Magento\Framework\Registry;
use Magento\Backend\Block\Template\Context;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\ResourceModel\Order\Invoice\CollectionFactory as InvoiceCollectionFactory;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Invoice;
use Magento\Framework\Api\SearchCriteria;
use Magento\Framework\Api\SearchResults;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;

class ViewTest extends TestCase
{
    private $contextMock;
    private $registryMock;
    private $orderRepositoryMock;
    private $invoiceCollectionFactoryMock;
    private $searchCriteriaBuilderMock;
    private $viewBlock;
    private $orderMock;
    private $invoiceMock;
    private $objectManager;

    protected function setUp(): void
    {
        $this->objectManager = new ObjectManager($this);

        $this->contextMock = $this->createMock(Context::class);
        $this->registryMock = $this->createMock(Registry::class);
        $this->orderRepositoryMock = $this->createMock(OrderRepositoryInterface::class);
        $this->invoiceCollectionFactoryMock = $this->createMock(InvoiceCollectionFactory::class);
        $this->searchCriteriaBuilderMock = $this->createMock(SearchCriteriaBuilder::class);

        $this->viewBlock = $this->objectManager->getObject(
            View::class,
            [
                'context' => $this->contextMock,
                'registry' => $this->registryMock,
                'orderRepository' => $this->orderRepositoryMock,
                'invoiceCollectionFactory' => $this->invoiceCollectionFactoryMock,
                'searchCriteriaBuilder' => $this->searchCriteriaBuilderMock
            ]
        );

        $this->orderMock = $this->createMock(Order::class);
        $this->invoiceMock = $this->createMock(Invoice::class);
    }

    public function testGetCustomerId()
    {
        $customerId = 1;
        $this->registryMock->method('registry')->with(\Magento\Customer\Controller\RegistryConstants::CURRENT_CUSTOMER_ID)->willReturn($customerId);

        $this->assertEquals($customerId, $this->viewBlock->getCustomerId());
    }

    public function testGetTabLabel()
    {
        $this->assertEquals('Invoices', $this->viewBlock->getTabLabel());
    }

    public function testGetTabTitle()
    {
        $this->assertEquals('Invoices', $this->viewBlock->getTabTitle());
    }

    public function testCanShowTab()
    {
        $customerId = 1;
        $this->registryMock->method('registry')->with(\Magento\Customer\Controller\RegistryConstants::CURRENT_CUSTOMER_ID)->willReturn($customerId);

        $this->assertTrue($this->viewBlock->canShowTab());
    }

    public function testIsHidden()
    {
        $customerId = 1;
        $this->registryMock->method('registry')->with(\Magento\Customer\Controller\RegistryConstants::CURRENT_CUSTOMER_ID)->willReturn($customerId);

        $this->assertFalse($this->viewBlock->isHidden());
    }

    public function testGetInvoiceDetails()
    {
        $customerId = 1;
        $this->registryMock->method('registry')->with(\Magento\Customer\Controller\RegistryConstants::CURRENT_CUSTOMER_ID)->willReturn($customerId);

        $searchCriteriaMock = $this->createMock(SearchCriteria::class);
        $this->searchCriteriaBuilderMock->method('addFilter')->willReturnSelf();
        $this->searchCriteriaBuilderMock->method('create')->willReturn($searchCriteriaMock);

        $searchResultsMock = $this->createMock(SearchResults::class);
        $this->orderRepositoryMock->method('getList')->with($searchCriteriaMock)->willReturn($searchResultsMock);
        $searchResultsMock->method('getItems')->willReturn([$this->orderMock]);

        $invoiceCollectionMock = $this->createMock(\Magento\Sales\Model\ResourceModel\Order\Invoice\Collection::class);
        $this->invoiceCollectionFactoryMock->method('create')->willReturn($invoiceCollectionMock);
        $invoiceCollectionMock->method('addAttributeToFilter')->with('order_id', $this->orderMock->getId())->willReturnSelf();
        $invoiceCollectionMock->method('getSize')->willReturn(1);
        $invoiceCollectionMock->method('getItems')->willReturn([$this->invoiceMock]);

        $this->orderMock->method('getCustomerEmail')->willReturn('mani@gmail.com');
        $this->orderMock->method('getCustomerFirstname')->willReturn('Manish');
        $this->orderMock->method('getCustomerLastname')->willReturn('Madhavan');
        $this->orderMock->method('getId')->willReturn(1);

        $this->invoiceMock->method('getIncrementId')->willReturn('000000002');
        $this->invoiceMock->method('getGrandTotal')->willReturn(100.00);
        $this->invoiceMock->method('getCreatedAt')->willReturn('2024-05-03 06:28:31');

        $expectedResult = [
            [
                'customer_email' => 'mani@gmail.com',
                'invoice_number' => '000000002',
                'amount' => 100.00,
                'invoice_date' => '2024-05-03 06:28:31',
                'customer_name' => 'Manish Madhavan',
            ],
        ];

        $this->assertEquals($expectedResult, $this->viewBlock->getInvoiceDetails());
    }
}
