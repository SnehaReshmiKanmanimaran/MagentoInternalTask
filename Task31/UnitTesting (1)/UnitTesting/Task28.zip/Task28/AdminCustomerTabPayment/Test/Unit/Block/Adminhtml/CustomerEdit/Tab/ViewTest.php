<?php

namespace Tychons\AdminCustomerTabPayment\Test\Unit\Block\Adminhtml\CustomerEdit\Tab;

use PHPUnit\Framework\TestCase;
use Tychons\AdminCustomerTabPayment\Block\Adminhtml\CustomerEdit\Tab\View;
use Magento\Framework\Registry;
use Magento\Backend\Block\Template\Context;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory as OrderCollectionFactory;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Item;
use Magento\Sales\Model\Order\Payment;
use Magento\Framework\View\Element\Template;

class ViewTest extends TestCase
{
    private $contextMock;
    private $registryMock;
    private $orderRepositoryMock;
    private $orderCollectionFactoryMock;
    private $searchCriteriaBuilderMock;
    private $viewBlock;
    private $orderMock;
    private $paymentMock;
    private $orderItemMock;

    protected function setUp(): void
    {
        $this->contextMock = $this->createMock(Context::class);
        $this->registryMock = $this->createMock(Registry::class);
        $this->orderRepositoryMock = $this->createMock(OrderRepositoryInterface::class);
        $this->orderCollectionFactoryMock = $this->createMock(OrderCollectionFactory::class);
        $this->searchCriteriaBuilderMock = $this->createMock(SearchCriteriaBuilder::class);

        $this->viewBlock = new View(
            $this->contextMock,
            $this->registryMock,
            $this->orderRepositoryMock,
            $this->orderCollectionFactoryMock,
            $this->searchCriteriaBuilderMock
        );

        $this->orderMock = $this->createMock(Order::class);
        $this->paymentMock = $this->createMock(Payment::class);
        $this->orderItemMock = $this->createMock(Item::class);
    }

    public function testGetCustomerId()
    {
        $customerId = 1;
        $this->registryMock->method('registry')->with(\Magento\Customer\Controller\RegistryConstants::CURRENT_CUSTOMER_ID)->willReturn($customerId);

        $this->assertEquals($customerId, $this->viewBlock->getCustomerId());
    }

    public function testGetTabLabel()
    {
        $this->assertEquals('Order Details', $this->viewBlock->getTabLabel());
    }

    public function testGetTabTitle()
    {
        $this->assertEquals('Order Details', $this->viewBlock->getTabTitle());
    }

    public function testCanShowTab()
    {
        $customerId = 1;
        $this->registryMock->method('registry')->with(\Magento\Customer\Controller\RegistryConstants::CURRENT_CUSTOMER_ID)->willReturn($customerId);

        $this->assertTrue($this->viewBlock->canShowTab());
    }

    public function testIsHidden()
    {
        $customerId = 1;
        $this->registryMock->method('registry')->with(\Magento\Customer\Controller\RegistryConstants::CURRENT_CUSTOMER_ID)->willReturn($customerId);

        $this->assertFalse($this->viewBlock->isHidden());
    }

    public function testGetCustomerOrders()
    {
        $customerId = 1;
        $this->registryMock->method('registry')->with(\Magento\Customer\Controller\RegistryConstants::CURRENT_CUSTOMER_ID)->willReturn($customerId);

        $orderCollectionMock = $this->createMock(\Magento\Sales\Model\ResourceModel\Order\Collection::class);
        $this->orderCollectionFactoryMock->method('create')->willReturn($orderCollectionMock);
        $orderCollectionMock->method('addFieldToFilter')->with('customer_id', $customerId)->willReturnSelf();
        $orderCollectionMock->method('setOrder')->with('created_at', 'desc')->willReturnSelf();
        $orderCollectionMock->method('getSize')->willReturn(1);

        $this->assertEquals($orderCollectionMock, $this->viewBlock->getCustomerOrders());
    }

    public function testGetOrderItems()
    {
        $this->orderMock->method('getAllItems')->willReturn([$this->orderItemMock]);
        $this->orderItemMock->method('getName')->willReturn('Test Product');
        $this->orderItemMock->method('getSku')->willReturn('test-sku');
        $this->orderItemMock->method('getPrice')->willReturn(100.00);
        $this->orderMock->method('getIncrementId')->willReturn('0000001');

        $expectedResult = [
            [
                'product_name' => 'Test Product',
                'product_sku' => 'test-sku',
                'product_price' => 100.00,
                'order_id' => '0000001'
            ]
        ];

        $this->assertEquals($expectedResult, $this->viewBlock->getOrderItems($this->orderMock));
    }

    public function testGetPaymentDetails()
    {
        $this->orderMock->method('getPayment')->willReturn($this->paymentMock);
        $this->paymentMock->method('getMethod')->willReturn('checkmo');
        $this->paymentMock->method('getCcType')->willReturn('VI');
        $this->paymentMock->method('getCcLast4')->willReturn('1234');
        $this->paymentMock->method('getCcOwner')->willReturn('John Doe');
        $this->paymentMock->method('getCcExpMonth')->willReturn('12');
        $this->paymentMock->method('getCcExpYear')->willReturn('2024');
        $this->paymentMock->method('getCcSsStartMonth')->willReturn('01');
        $this->paymentMock->method('getCcSsStartYear')->willReturn('2020');
        $this->paymentMock->method('getCcSsIssue')->willReturn('123456');

        $expectedResult = [
            'method' => 'checkmo',
            'additional_information' => null,
            'cc_type' => 'VI',
            'cc_last4' => '1234',
            'cc_owner' => 'John Doe',
            'cc_exp_month' => '12',
            'cc_exp_year' => '2024',
            'cc_ss_start_month' => '01',
            'cc_ss_start_year' => '2020',
            'cc_ss_issue' => '123456',
        ];

        $this->assertEquals($expectedResult, $this->viewBlock->getPaymentDetails($this->orderMock));
    }
}
